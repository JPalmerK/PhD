%% Listening Range as a function of SNR %%

close all; clear all; clc;
cd('W:\KJP PHD\3-Detection Function\Propagation Model\Code')
floc='W:\KJP PHD\3-Detection Function\Propagation Model\BathData\';
bath_floc='Z:\PropModelBathData\';
set(0, 'DefaulttextInterpreter', 'none')
%% Deployment lat/long
Dep_loc=table(['Arb_10'; 'Arb_15';'Arb_05';...
    'Cro_10';	'Cro_15';	'Cro_05';...
    'Cru_10';	'Cru_15';	'Cru_05';...
    'Fra_10';	'Fra_15';	'Fra_05';...
    'Hel_10';	'Hel_15';	'Hel_05';...
    'Lat_10';	'Lat_15';	'Lat_05';...
    'SpB_10';	'SpB_15';	'SpB_05';...
    'Stb_10';	'Stb_15';	'Stb_05';...
    'StA_10';	'StA_15';	'StA_05';...
    'Sto_10';	'Sto_15';	'Sto_05'],...
[56.49963; 56.45947; 56.55413; 57.68911; 57.70653; 57.67517;...
    57.38005; 57.37742; 57.37994; 57.77086; 57.84925; 57.71136;...
    58.00499; 57.97563; 58.05338; 58.22928; 58.18665; 58.26933;...
    57.74148; 57.78529; 57.68989; 55.96354; 56.03334; 55.9292;...
    56.25781; 56.29021; 56.26576; 56.95927; 56.98069; 56.94688],...
   [-2.38019;	-2.29861;	-2.48347;	-3.88155;	-3.81024;	-3.98799;...
    -1.73735;	-1.61812;	-1.82851;	-2.13963;	-2.08936;	-2.12987;...
    -3.61127;	-3.5361;	-3.71525;	-3.2065;	-3.13512;	-3.31806;...
    -3.03874;	-3.05898;	-3.06196;	-2.16201;	-2.07546;	-2.17725;...
    -2.49871;	-2.43311;	-2.571429;	-2.11361;	-2.02194;	-2.17688],...
    zeros(30,1), zeros(30,1), 'VariableNames',{'Loc', 'Lat', 'Lon', 'UTMX', 'UTMY'});

Dep_loc.Var6(14,1) = 7;
Dep_loc.Properties.VariableNames{6} = 'SMNumber';

Dep_loc.SMNumber(12) = 4;
Dep_loc.SMNumber(30) = 12;
Dep_loc.SMNumber(24) = 3;
Dep_loc.SMNumber(25) = 9;
Dep_loc.SMNumber(19) = 10;
Dep_loc.SMNumber(5) = 15;
Dep_loc.SMNumber(18) = 13;
Dep_loc.SMNumber(9) = 6;
Dep_loc.SMNumber(1) = 5;


[Dep_loc.UTMX, Dep_loc.UTMY] = deg2utm(Dep_loc.Lat,Dep_loc.Lon);
%% Set up some Constants and Empty Variables %% 

% Make up some Noise Levels
NL=[0:1:200];

% The frequency (hz) to run the bellhop model (5 or 40khz)
freq=[5000 15000 20000 25000 30000 35000 40000 45000 48000 50000];


%% Read in the bathymetric Data %%


% Click SL
SL_click=213; %dB from Zimmer pg 89
Min_SNR=1;

Mean_AreavsNL=table(cellstr(Dep_loc.Loc), 'VariableNames', {'DepLoc'});
Mean_AreavsNL=[Mean_AreavsNL array2table(zeros(30,length(NL)))];


for ii=1:30
  
    EDR=zeros(length(freq), length(NL));
    for ff=1:length(freq)
        % place to store the Area
       

            % Load the bathymetry grid;
            fname=Dep_loc.Loc(ii,:);

            % Use this if grids are unprocessed or single
            [bath_grid, A]=getbathgrid(bath_floc, [fname '.asc']);
            % index of the hydrophone in MATLAB space
            HydXYZ=[nearest2(A.Lat, Dep_loc.UTMX(ii,:)) nearest2(A.Lon, Dep_loc.UTMY(ii,:))];
            HydXYZ(3)=bath_grid(HydXYZ(2), HydXYZ(1));


            TL_fname=['W:\KJP PHD\3-Detection Function\Propagation Model\TL_Grids\TL_' fname '_'...
            num2str(freq(ff)/1000) 'kHz_20rad'];
            load(TL_fname)

            GridX=A.meta{9,2};
            GridY=A.meta{10,2};

            % Get the Area Monitored
              
                % Add rose plot
                [EDR(ff,:)]=EDRMonitored(TL_grids, SL_click, NL);       

        
        

            
            
    end
    
   % Weighting Factor
   yy=-((.0135*((freq/1000)-40)).^2)+1;
   % weighting factor
   w=yy/sum(yy);
   kk=w*EDR;
   
   Mean_AreavsNL(ii,2:end)=array2table(kk);
   
%    figure
%    hold on
%    plot(area_monitored')
%    plot(kk, '*k')
%    l1=legend([cellstr(num2str(freq'/1000)); {'Weighted mean'}])
%    mm=get(l1, 'Title')
%    set(mm, 'String', 'kHz', 'EdgeColor', [0,0,0])
%    xlabel('NL dB')
%    ylabel('km^2')
%    title(cellstr(Dep_loc.Loc(ii,:)))
   
 
    
end
%%

for ii=2:width(Mean_AreavsNL)
    Mean_AreavsNL.Properties.VariableNames(ii)=cellstr(['dB_' num2str(NL(ii-1))]);
end
 csv_loc='W:\KJP PHD\3-Detection Function\Propagation Model\Area_vs_NL\';
 csv_nam=['EDRVsNL07Apr'];
 writetable(Mean_AreavsNL, [csv_loc csv_nam])

    
idx=find(Dep_loc.SMNumber>0)
plot(Mean_AreavsNL{idx, 2:end}')
legend(cellstr(Dep_loc.Loc(idx,:)))
title('Area vs NL')
xlabel('NL')
ylabel('Area Monitored (km^2)')


