
function [EDA ]=EDRMonitored(TL_grids, SL, NL)
% This function take in the the transmission loss grids and static valuse
% for the mininimum detectable SNR, estimated source level and ambient noise 
% level. The output is the EFFECTIVE area monitored for a given noise level

% EDR is estimated by simulating 10k sources within 7km of the unit
% Assume a maximum SL for each source and calculate SNR

% Pdet is given by 1./(1+exp(-(1.5*SNR-114))), this would depend on the
% system

% Dane et al 2013 reprth that
% C-PODs have a detection threshold (linear model) of
% 114.561.2 (standard deviation) dB re 1 lPa peak�peak at
% 130 kHz. The difference between the most and least sensitive
% instrument was found to be 7.1 dB re 1 lPa peak�peak.

% At 60khz the RLlm and RL50 thresholds are approximately 120



% Range is the Range in meters


if ~isfield(TL_grids, 'meanp')
    for ii=1:length(TL_grids)

        rd=0:.5:round(max(TL_grids(ii).bath(:,2))+10);  
        TL_grids(ii).meanp=getmeanp(TL_grids(ii).pa, TL_grids(ii).bath, rd);

    end
end


    % Assume a maximum detection radius
    rr=betarnd(2,1, [1,100000])*7;
    
    % Sigma for beta distribution
    sig=1.5;
    
    % Effective Detection Area
    EDA=zeros(1,length(NL));
    
for jj=1:length(NL)   
    % Effective Detection Radius
    EDR=zeros(1, length(TL_grids));
    
    for ii=1:length(TL_grids)
        
        % Histogram bin values
        mm=hist(rr*1000, TL_grids(ii).range(2:end));
        
        % SNR for bin values for each histogram bin
        SNR=SL-TL_grids(ii).meanp(2:end)-NL(jj);
        
        % Pdet values for each histogram bin
        pdet=1./(1+exp(-(sig*SNR-114)));
        
        
        % number of detections captured sources
        capt=zeros(1, length(mm));
    
        for kk=1:length(mm)
             
            capt(kk)=sum(rand(mm(kk),1) < pdet(kk));

        end
        
        cum_capts=cumsum(capt);
        
        % EDR is the distance from the sampling point 
        % at which as many birds are detected beyond EDR as remained undetected within EDR
        edr_idx=nearest2(cum_capts, sum(capt)/2);
        
        if ~isempty(edr_idx)
            EDR(ii)=TL_grids(ii).range((edr_idx+1)); % range in meters
        else
            EDR(ii)=0;
        end

        
        % Get the SNR for each source based on it's range from the sensor
        
    end
    

    EDA(jj)=sum(pi*EDR.^2/length(TL_grids)); % in meters squared
    sprintf(num2str(jj));

end

 EDA= EDA/1000000; % Now in square kilometers

end