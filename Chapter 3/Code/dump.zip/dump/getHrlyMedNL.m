function [med_NL Jdate_hrs stdev_NL mean_NL]=getHrlyMedNL(Jdate_out, NL_out)

% Function to get the median hourly  Noise level from whatever octabve band
% Assumes NL out has been calculated elsewhere

hrs=unique(floor(Jdate_out*24));
med_NL=zeros(length(hrs),1);
stdev_NL=med_NL;
mean_NL=med_NL;
for zz=1:length(hrs)-1

    med_NL(zz)=median(NL_out(Jdate_out*24<hrs(zz+1) & Jdate_out*24>=hrs(zz)));
    stdev_NL(zz)=std(NL_out(Jdate_out*24<hrs(zz+1) & Jdate_out*24>=hrs(zz)));
    mean_NL(zz)=mean(NL_out(Jdate_out*24<hrs(zz+1) & Jdate_out*24>=hrs(zz)));
end

Jdate_hrs=hrs/24;

%csvwrite('W:\CPOD Basian Analysis\NL Text Files\SM2MedHrly.csv', med_NL)
end